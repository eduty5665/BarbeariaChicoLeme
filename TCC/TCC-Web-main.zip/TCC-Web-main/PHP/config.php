<?php
$serverName = "ChicoBD.mssql.somee.com";
$databaseName = "ChicoBD";
$uid = "Pyisaac17_SQLLogin_1";
$pwd = "xyl3m6ie5h";

try {
    $conn = new PDO("sqlsrv:Server=$serverName;Database=$databaseName", $uid, $pwd);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    // Agora você pode executar consultas e interagir com o banco de dados aqui

} catch (PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}