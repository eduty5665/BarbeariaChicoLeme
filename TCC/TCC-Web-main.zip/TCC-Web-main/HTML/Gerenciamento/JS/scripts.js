function validaForm(){
    window.alert('Venda Registrada!')
}